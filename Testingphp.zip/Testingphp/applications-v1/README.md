# Applications List

A repo to store the public portion of the applications project.

---

## Project Stack

This project uses [HTML](https://www.w3schools.com/html), [CSS](https://www.w3schools.com/css), [JavaScript](https://developer.mozilla.org/en-US/docs/Web/JavaScript) and [W3.CSS](https://www.w3schools.com/w3css).

<img src="https://console.codeadam.ca/api/image/w3css" width="60"> <img src="https://console.codeadam.ca/api/image/html" width="60"> <img src="https://console.codeadam.ca/api/image/css" width="60"> <img src="https://console.codeadam.ca/api/image/javascript" width="60">

---

## Repo Resources

* [BrickMMO](https://www.brickmmo.com/)
* [Applications](https://applications.brickmmo.com/)

<a href="https://brickmmo.com">
<img src="https://cdn.brickmmo.com/images@1.0.0/brickmmo-logo-coloured-horizontal.png" width="200">
</a>

